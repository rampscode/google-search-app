import React from 'react';

function Test(props) {
    return (
        <div>
            tes
        </div>
    );
}

export default Test;